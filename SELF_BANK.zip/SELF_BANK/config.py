#行方SIT环境数据库信息
ZD_bank_Mysql_Host = '172.16.40.94'
ZD_bank_Mysql_Port = 3306
ZD_bank_Mysql_User = 'm_plc_data'
ZD_bank_Mysql_Passwd = 'wcPqCp'
ZD_bank_Mysql_DB = 'plc_data'
#内部SIT环境数据库信息y
SELF_Mysql_Host = '172.16.40.61'
SELF_Mysql_Port= 3306
SELF_Mysql_User = 'm_plc_data'
SELF_Mysql_Passwd = '7qobcL'
SELF_Mysql_DB = 'plc_data'
#内部多服务测试环境
Mysql_Host = '192.168.58.197'
Mysql_Port= 3306
Mysql_User = 'root'
Mysql_Passwd = ''
Mysql_DB = 'zdbk_dev'
