# 2020/12/22
# author:xieyudong
import pymysql
from tools import *
import random
db = choose_env('test')
cursor = db.cursor()
def insert_to_plc_loan_data(per_no,pdu_no,lon_no,overdueAmount):
    """
    :param per_no: 账户号
    :param pdu_no: 产品号
    :param lon_no: 借据号
    :return:
    """
    account_no = str(per_no)+str(pdu_no)
    reason_code = 'DELAY'
    #批次号
    batch_no = get_batch_no()
    #客户号
    personal_no = per_no
    #产品编号
    product_no = pdu_no
    product_version = '1.0.0'
    #借据号
    loan_no = lon_no
    contract_number = 'CHO100100001'
    loan_date = get_time('otime')
    loan_capital = 1000.99
    total_periods = random.randint(1,12)
    loan_term = '一个月'
    no_repay_capital = round(random.uniform(1000.01,100000),4)
    repaid_capital = round(random.uniform(1000.01,100000),4)
    overdue_stage = 'M1'
    overdue_days = '30'
    should_repay_amount = round(random.uniform(1000.01,100000),4)
    min_should_repay_amount = round(random.uniform(1000.01,100000),4)
    overdue_amount = overdueAmount
    min_overdue_amount = round(random.uniform(1000.01,100000),4)
    overdue_capital = round(random.uniform(1000.01,100000),4)
    overdue_interest  = round(random.uniform(1000.01,100000),4)
    overdue_fine  = round(random.uniform(1000.01,100000),4)
    overdue_compound  = round(random.uniform(1000.01,100000),4)
    overdue_other_fee  = round(random.uniform(1.00,5.01),2)
    m1_amount  = round(random.uniform(1000.01,100000),4)
    m2_amount  = round(random.uniform(1000.01,100000),4)
    m3_amount  = round(random.uniform(1000.01,100000),4)
    m4_amount  = round(random.uniform(1000.01,100000),4)
    m5_amount  = round(random.uniform(1000.01,100000),4)
    m6_amount  =round(random.uniform(1000.01,100000),4)
    after_m6_amount  = round(random.uniform(1000.01,100000),4)
    afterm6amount  = round(random.uniform(1000.01,100000),4)
    m1amount  = round(random.uniform(1000.01,100000),4)
    m2amount  = round(random.uniform(1000.01,100000),4)
    m3amount  = round(random.uniform(1000.01,100000),4)
    m4amount  = round(random.uniform(1000.01,100000),4)
    m5amount  = round(random.uniform(1000.01,100000),4)
    m6amount  = round(random.uniform(1000.01,100000),4)
    datalist = []
    data = (
        (
        account_no,
        reason_code,
        batch_no,
        personal_no,
        product_no,
        product_version,
        loan_no,
        contract_number,
        loan_date,
        loan_capital,
        total_periods,
        loan_term,
        no_repay_capital,
        repaid_capital,
        overdue_stage,
        overdue_days,
        should_repay_amount,
        min_should_repay_amount,
        overdue_amount,
        min_overdue_amount,
        overdue_capital,
        overdue_interest,
        overdue_fine,
        overdue_compound,
        overdue_other_fee,
        m1_amount,
        m2_amount,
        m3_amount,
        m4_amount,
        m5_amount,
        m6_amount,
        after_m6_amount,
        afterm6amount,
        m1amount,
        m2amount,
        m3amount,
        m4amount,
        m5amount,
        m6amount
        )
    )
    datalist.append(data)

    sql = """insert into plc_loan_temp(
        account_no,
        reason_code,
        batch_no,
        personal_no,
        product_no,
        product_version,
        loan_no,
        contract_number,
        loan_date,
        loan_capital,
        total_periods,
        loan_term,
        no_repay_capital,
        repaid_capital,
        overdue_stage,
        overdue_days,
        should_repay_amount,
        min_should_repay_amount,
        overdue_amount,
        min_overdue_amount,
        overdue_capital,
        overdue_interest,
        overdue_fine,
        overdue_compound,
        overdue_other_fee,
        m1_amount,
        m2_amount,
        m3_amount,
        m4_amount,
        m5_amount,
        m6_amount,
        after_m6_amount,
        afterm6amount,
        m1amount,
        m2amount,
        m3amount,
        m4amount,
        m5amount,
        m6amount
    )values(
    %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
    %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
    %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
    %s,%s,%s,%s,%s,%s,%s,%s,%s
         )
    """
    cursor.executemany(sql,datalist)
    db.commit()
if __name__ == '__main__':
    insert_to_plc_loan_data(get_personal_no(), get_product_no(), get_loan_no())
