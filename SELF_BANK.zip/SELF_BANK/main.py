from plc_personal_temp import *
from plc_loan_temp import *
from plc_account_temp import *
from plc_personal_contact_temp import *
from plc_push_record import *
def insert_data_scene(dataScene):
    """
    选择数据场景
    :param dataScene:
    :return:
    """
    insert_plc_push_record()
    count = 1
    while count<=5:
        #单客户，单账户，单借据
        if dataScene == 'single_scene':
            #获取客户号
            prsonal_no1 = get_personal_no()
            # 身份证号
            id_card = get_id_card()
            #产品号
            produ_no = get_product_no()
            #账户逾期总金额
            Omoney = get_overdue_amount()
            #账户总金额
            Cmoney = get_caseMoney()
            # 客户表里面插入一个客户信息
            insert_to_personal_temp(prsonal_no1,id_card,get_user_type())
            #客户联系人表插入一个客户信息
            insert_to_plc_personal_contact_data(prsonal_no1)
            #给账户表里面插入一条账户信息
            insert_to_plc_account_data(prsonal_no1, produ_no,get_overDue_date(),'DELAY',Omoney,Cmoney)
            #给借据表里面插入一条借据号
            insert_to_plc_loan_data(prsonal_no1,produ_no,get_loan_no(),Omoney)
            print(str(prsonal_no1)+str(produ_no))
        #单客户，多账户，多借据场景
        elif dataScene == 'double_scene':
            prsonal_no2 = get_personal_no()
            id_card = get_id_card()
            #给客户号插入一个客户
            insert_to_personal_temp(prsonal_no2,id_card,get_user_type())
            #一个客户号下面三个账户号
            for i in range(1,4):
                insert_to_plc_personal_contact_data(prsonal_no2)
            for i in range(1,4):
                product_no1 = get_product_no()
                # 账户逾期总金额
                Omoney = get_overdue_amount()
                # 账户总金额
                Cmoney = get_caseMoney()
                if i == 1:
                    insert_to_plc_account_data(prsonal_no2,product_no1,get_overDue_date(),'DELAY',Omoney,Cmoney)
                elif i == 2:
                    insert_to_plc_account_data(prsonal_no2, product_no1, get_overDue_date(), 'RELATION', Omoney,Cmoney)
                else:
                    insert_to_plc_account_data(prsonal_no2, product_no1, get_overDue_date(), get_reason_code(), Omoney, Cmoney)
                for j in range(1,4):
                    insert_to_plc_loan_data(prsonal_no2,product_no1,get_loan_no(),Omoney)
                print(str(prsonal_no2) + str(product_no1))
        count+=1
if __name__ == '__main__':
    insert_data_scene('single_scene')
