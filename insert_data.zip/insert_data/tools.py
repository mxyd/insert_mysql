import pymysql
import time,datetime
from SELF_BANK.config import *
#from config import *
import random
def get_time(ptime):
    """
    :param ptime: 判断时间精确到秒还是精确到日
    :return:
    """
    local_time = time.localtime()
    year = local_time.tm_year
    mouth = local_time.tm_mon
    day = local_time.tm_mday
    hour = local_time.tm_hour
    minute = local_time.tm_min
    second = local_time.tm_sec
    if ptime == 'precise_time':
        createTime = f'{year}-{mouth}-{day} {hour}:{minute}:{second}'
    elif ptime == 'otime':
        createTime = f'{year}-{mouth}-{day}'
    return createTime

def choose_env(environment):
    """
    :param environment: 判断环境环境
    :return:
    """
    if environment == 'ZD':
        db = pymysql.connect(host=ZD_bank_Mysql_Host, port=ZD_bank_Mysql_Port, user=ZD_bank_Mysql_User,passwd=ZD_bank_Mysql_Passwd, db=ZD_bank_Mysql_DB, charset='utf8')
    elif environment == 'SELF':
        db = pymysql.connect(host=SELF_Mysql_Host, port=SELF_Mysql_Port,user=SELF_Mysql_User,passwd=SELF_Mysql_Passwd,db=SELF_Mysql_DB,charset='utf8')
    elif environment == 'test':
        db = pymysql.connect(host=Mysql_Host, port=Mysql_Port, user=Mysql_User, passwd=Mysql_Passwd,db=Mysql_DB, charset='utf8')
    return db
def get_personal_no():
    """
    获取到一个客户号
    :return:
    """
    personal_no = random.randint(10000001,99999999)
    return personal_no
def get_product_no():
    """
    获取产品号
    :return:
    """
    product_no = random.randint(100,999)
    return product_no
def get_account_no():
    """
    获取账户号
    :return:
    """
    account_no = str(get_personal_no()) + str(get_product_no())
    return int(account_no)
def get_batch_no():
    """
    获取批次号
    :return: 
    """
    batch_no = random.randint(1000,9999)
    return batch_no
def get_loan_no():
    """
      获取借据号
    :return: 
    """
    loan_no = random.randint(10001,99999)
    return loan_no
def get_name():
    """
    获取姓名
    :return:
    """
    name = '张' + str(random.randint(1,50))
    return name
def get_bank_card_number():
    """
    获取银行卡号
    :return:
    """
    card_number = random.randint(6221210000000000000,6221218888888888888)
    return card_number
def get_pnone_number():
    """
    获取手机号
    :return:
    """
    phone_number = random.randint(13000000000,19999999999)
    return phone_number
def get_id_card():
    """
    获取身份证号
    :return:
    """
    id_card = random.randint(610121196701011111,610121202001019999)
    return id_card
def get_user_type():
    userTypeList = ['ENTERPRISE','PERSONAL']
    return userTypeList[random.randrange(0,len(userTypeList))]
def get_overDue_date():
    """
    获取逾期日期
    :return:
    """
    a1 = (2019, 1, 1, 0, 0, 0, 0, 0, 0)      # 设置开始日期时间元组（1976-01-01 00：00：00）
    a2 = (2021, 1, 12, 23, 59, 59, 0, 0, 0)
    start = time.mktime(a1)  # 生成开始时间戳
    end = time.mktime(a2)
    t = random.randint(start, end)  # 在开始和结束时间戳中随机取出一个
    date_touple = time.localtime(t)  # 将时间戳生成时间元组
    date = time.strftime("%Y-%m-%d", date_touple)  # 将时间元组转成格式化字符串（1976-05-21）
    # print(type(date))
    test_time = datetime.datetime.strptime(date,'%Y-%m-%d')
    # return test_time
    return datetime.datetime.date(test_time)
def get_reason_code():
    """
    获取入催原因
    :return:
    """
    reason_code_list = ['DELAY','RELATION']
    reason_code = reason_code_list[random.randrange(0,len(reason_code_list))]
    return reason_code
def get_overdue_amount():
    """
    获取逾期总金额
    :return:
    """
    overdue_amount_list = [500,1000,1500,2000,2500]
    return overdue_amount_list[random.randrange(0,len(overdue_amount_list))]
def get_caseMoney():
    """
    获取总金额
    :return:
    """
    caseMoney_list = [3000,4000,5000,6000,7000]
    return caseMoney_list[random.randrange(0,len(caseMoney_list))]
if __name__ == '__main__':
   print(get_overdue_amount())
   # print(type(get_overDue_date()))

    # print(choose_env('ZD'))

    # get_time('precise_time')
    # print(get_time('precise_time'))