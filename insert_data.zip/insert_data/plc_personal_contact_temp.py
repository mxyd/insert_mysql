import pymysql
import datetime
from tools import *
db = choose_env('test')
cursor = db.cursor()
def insert_to_plc_personal_contact_data(pon):
    """
    :param pno: 客户号
    :return: 
    """
    batch_no = get_batch_no()
    personal_no = pon
    cont_type = 'SELF'
    cont_name = get_name()
    phone = get_pnone_number()
    company_name = '上海招东1'
    company_phone = get_pnone_number()
    cont_address = '上海市龙阳路101'
    fixed_phone = get_pnone_number()
    post = '打工人'
    address_type = 'HOME'
    province = '上海'
    city = '上海'
    postcode = 'H888888'
    full_address = '上海市龙阳路101'
    update_time = get_time('precise_time')
    dataList = []
    data = (
        (
            batch_no,
            personal_no,
            cont_type,
            cont_name,
            phone,
            company_name,
            company_phone,
            cont_address,
            fixed_phone,
            post,
            address_type,
            province,
            city,
            postcode,
            full_address,
            update_time
        )
    )
    dataList.append(data)
    sql = """ insert into plc_personal_contact_temp(
            batch_no,
            personal_no,
            cont_type,
            cont_name,
            phone,
            company_name,
            company_phone,
            cont_address,
            fixed_phone,
            post,
            address_type,
            province,
            city,
            postcode,
            full_address,
            update_time
    )values(
             %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
             %s,%s,%s,%s,%s,%s
    )
    """
    cursor.executemany(sql,dataList)
    db.commit()