# 2020/12/22
# author:xieyudong
import pymysql
import datetime
from tools import *
db = choose_env('test')
cursor = db.cursor()
def insert_to_plc_account_data(per_no1,pdu_no1,overdueDate,r_code,overdueAmount,caseMoney):
    """

    :param per_no1: 客户号
    :param pdu_no1: 产品号
    :param overdueDate: 逾期日期
    :param r_code: 入催原因
    :return:
    """
    batch_no = get_batch_no()
    personal_no = per_no1
    product_type = '房贷'
    product_no = pdu_no1
    product_channel = '房产渠道'
    account_no = int(str(per_no1)+str(pdu_no1))
    reason_code = r_code
    bill_date = get_time('otime')
    pay_date = get_time('otime')
    pre_bill_date = get_time('otime')
    next_bill_date = get_time('otime')
    pre_pay_date = get_time('otime')
    next_pay_date = get_time('otime')
    #overdue_stage = ['M1','M5','M1','M3','M10']
    repay_rating = '优'
    overdue_loans = 1
    deduction_card_number = get_bank_card_number()
    deduction_card_bank = '中国银行'
    deduction_card_flag = '是'
    replace_card_number = get_bank_card_number()
    monitor_flag = '有变动'
    risk_control_code = 'N001'
    risk_control_update_time = get_time('precise_time')

    pre_risk_control_code = 'PR001'
    pre_risk_control_update_time = get_time('precise_time')
    risk_status = '有风险'
    risk_status_update_date = get_time('otime')
    risk_status_update_agent = get_name()
    risk_status_update_reason = '长时间未还款'
    plan_balance = round(random.uniform(1000.01,1000000),4)
    case_money = caseMoney
    small_amount_flag = '小'
    capital_balance = round(random.uniform(1000.01,1000000),4)
    interest_balance = round(random.uniform(1000.01,1000000),4)
    fine_balance = round(random.uniform(1000.01,1000000),4)
    compound_balance = round(random.uniform(1000.01,1000000),4)
    other_fee_balance =round(random.uniform(1000.01,1000000),4)
    should_repay_amount = round(random.uniform(1000.01,1000000),4)
    min_should_repay_amount = round(random.uniform(1000.01,1000000),4)
    overdue_amount = overdueAmount
    min_overdue_amount = round(random.uniform(1000.01,1000000),4)
    overdue_capital = round(random.uniform(1000.01,1000000),4)
    overdue_interest = round(random.uniform(1000.01,1000000),4)
    overdue_fine = round(random.uniform(1000.01,1000000),4)
    overdue_compound =  round(random.uniform(1000.01,1000000),4)
    overdue_other_fee = 1.03,
    m1_amount= round(random.uniform(1000.01,1000000),4)
    m2_amount  = round(random.uniform(1000.01,1000000),4)
    m3_amount  = round(random.uniform(1000.01,1000000),4)
    m4_amount  = round(random.uniform(1000.01,1000000),4)
    m5_amount  = round(random.uniform(1000.01,1000000),4)
    m6_amount  = round(random.uniform(1000.01,1000000),4)
    after_m6_amount  = round(random.uniform(1000.01,1000000),4)
    lately_pay_date = get_time('precise_time')
    lately_pay_amount = round(random.uniform(1000.01,1000000),4)
    net_interest_flag = '无'
    history_max_overdue_stage = 'M12'
    history_max_overdue_stage_flag = '最高'
    history_max_overdue_amount = round(random.uniform(1000.01,1000000),4)
    total_loans = 5
    balance_loans = 5
    delay_loans = 5
    first_overdue_m2_date = get_time('precise_time')
    first_overdue_m2_amount = round(random.uniform(1000.01,1000000),4)
    first_overdue_m3_date = get_time('precise_time')
    first_overdue_m3_amount = round(random.uniform(1000.01,1000000),4)
    first_overdue_m7_date = get_time('precise_time')
    first_overdue_m7_amount = round(random.uniform(1000.01,1000000),4)
    overdue_days = random.randint(30,500)
    guaranty_type = '房产'
    guaranty = '房产'
    guarantee_name = get_name()
    guarantee_id_card = get_bank_card_number()
    guarantee_no = random.randint(900000,999999)
    guarantee_phone = get_pnone_number()
    guarantee_adress = '上海龙阳路'
    quaranty_limit = round(random.uniform(1000.01,1000000),4)
    contract_number = 'SQ0003'
    credit_limit = round(random.uniform(1000.01,1000000),4)
    current_limit = round(random.uniform(1000.01,1000000),4)
    used_limit = round(random.uniform(1000.01,1000000),4)
    available_limit = round(random.uniform(1000.01,1000000),4)
    should_repay_limit_rate = round(random.uniform(1000.01,1000000),4)
    total_limit_rate = 100
    first_use_date = get_time('precise_time')
    history_delay_flag = '是'
    half_year_repay_times = 6
    first_m7_months = 7
    out_days = 15
    out_date_stage = get_time('otime')
    no_repay_flag = '是'
    afterm6amount = random.random()
    firstm7months = 5
    first_overduem2amount = round(random.uniform(1000.01,1000000),4)
    first_overduem2date = get_time('precise_time')
    first_overduem3amount = round(random.uniform(1000.01,1000000),4)
    first_overduem3date = get_time('precise_time')
    first_overduem7amount = round(random.uniform(1000.01,1000000),4)
    first_overduem7date = get_time('precise_time')
    m1amount  = round(random.uniform(1000.01,1000000),4)
    m2amount  = round(random.uniform(1000.01,1000000),4)
    m3amount  = round(random.uniform(1000.01,1000000),4)
    m4amount  = round(random.uniform(1000.01,1000000),4)
    m5amount  = round(random.uniform(1000.01,1000000),4)
    m6amount  = round(random.uniform(1000.01,1000000),4)
    time_created = get_time('precise_time')
    time_modified = get_time('precise_time')
    # created_time = get_time('precise_time')
    # modified_time = get_time('precise_time')
    overdue_date = overdueDate
    dataList = []
    data = (
        (
            batch_no,
            personal_no,
            product_type,
            product_no,
            product_channel,
            account_no,
            reason_code,
            bill_date,
            pay_date,
            pre_bill_date,
            next_bill_date,
            pre_pay_date,
            next_pay_date,
            #overdue_stage,
            repay_rating,
            overdue_loans,
            deduction_card_number,
            deduction_card_bank,
            deduction_card_flag,
            replace_card_number,
            monitor_flag,
            risk_control_code,
            risk_control_update_time,
            pre_risk_control_code,
            pre_risk_control_update_time,
            risk_status,
            risk_status_update_date,
            risk_status_update_agent,
            risk_status_update_reason,
            plan_balance,
            case_money,
            small_amount_flag,
            capital_balance,
            interest_balance,
            fine_balance,
            compound_balance,
            other_fee_balance,
            should_repay_amount,
            min_should_repay_amount,
            overdue_amount,
            min_overdue_amount,
            overdue_capital,
            overdue_interest,
            overdue_fine,
            overdue_compound,
            overdue_other_fee,
            m1_amount,
            m2_amount,
            m3_amount,
            m4_amount,
            m5_amount,
            m6_amount,
            after_m6_amount,
            lately_pay_date,
            lately_pay_amount,
            net_interest_flag,
            history_max_overdue_stage,
            history_max_overdue_stage_flag,
            history_max_overdue_amount,
            total_loans,
            balance_loans,
            delay_loans,
            first_overdue_m2_date,
            first_overdue_m2_amount,
            first_overdue_m3_date,
            first_overdue_m3_amount,
            first_overdue_m7_date,
            first_overdue_m7_amount,
            overdue_days,
            guaranty_type,
            guaranty,
            guarantee_name,
            guarantee_id_card,
            guarantee_no,
            guarantee_phone,
            guarantee_adress,
            quaranty_limit,
            contract_number,
            credit_limit,
            current_limit,
            used_limit,
            available_limit,
            should_repay_limit_rate,
            total_limit_rate,
            first_use_date,
            history_delay_flag,
            half_year_repay_times,
            first_m7_months,
            out_days,
            out_date_stage,
            no_repay_flag,
            afterm6amount,
            firstm7months,
            first_overduem2amount,
            first_overduem2date,
            first_overduem3amount,
            first_overduem3date,
            first_overduem7amount,
            first_overduem7date,
            m1amount,
            m2amount,
            m3amount,
            m4amount,
            m5amount,
            m6amount,
            time_created,
            time_modified,
            #created_time,
            #modified_time,
            overdue_date,
        )
    )
    dataList.append(data)
    sql = """ insert into plc_account_temp(
        batch_no,
        personal_no,
        product_type,
        product_no,
        product_channel,
        account_no,
        reason_code,
        bill_date,
        pay_date,
        pre_bill_date,
        next_bill_date,
        pre_pay_date,
        next_pay_date,
        repay_rating,
        overdue_loans,
        deduction_card_number,
        deduction_card_bank,
        deduction_card_flag,
        replace_card_number,
        monitor_flag,
        risk_control_code,
        risk_control_update_time,
        pre_risk_control_code,
        pre_risk_control_update_time,
        risk_status,
        risk_status_update_date,
        risk_status_update_agent,
        risk_status_update_reason,
        plan_balance,
        case_money,
        small_amount_flag,
        capital_balance,
        interest_balance,
        fine_balance,
        compound_balance,
        other_fee_balance,
        should_repay_amount,
        min_should_repay_amount,
        overdue_amount,
        min_overdue_amount,
        overdue_capital,
        overdue_interest,
        overdue_fine,
        overdue_compound,
        overdue_other_fee,
        m1_amount,
        m2_amount,
        m3_amount,
        m4_amount,
        m5_amount,
        m6_amount,
        after_m6_amount,
        lately_pay_date,
        lately_pay_amount,
        net_interest_flag,
        history_max_overdue_stage,
        history_max_overdue_stage_flag,
        history_max_overdue_amount,
        total_loans,
        balance_loans,
        delay_loans,
        first_overdue_m2_date,
        first_overdue_m2_amount,
        first_overdue_m3_date,
        first_overdue_m3_amount,
        first_overdue_m7_date,
        first_overdue_m7_amount,
        overdue_days,
        guaranty_type,
        guaranty,
        guarantee_name,
        guarantee_id_card,
        guarantee_no,
        guarantee_phone,
        guarantee_adress,
        quaranty_limit,
        contract_number,
        credit_limit,
        current_limit,
        used_limit,
        available_limit,
        should_repay_limit_rate,
        total_limit_rate,
        first_use_date,
        history_delay_flag,
        half_year_repay_times,
        first_m7_months,
        out_days,
        out_date_stage,
        no_repay_flag,
        afterm6amount,
        firstm7months,
        first_overduem2amount,
        first_overduem2date,
        first_overduem3amount,
        first_overduem3date,
        first_overduem7amount,
        first_overduem7date,
        m1amount,
        m2amount,
        m3amount,
        m4amount,
        m5amount,
        m6amount,
        time_created,
        time_modified,
        overdue_date
    )values(
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s)
    """
    cursor.executemany(sql,dataList)
    db.commit()
if __name__ == '__main__':
    insert_to_plc_account_data(get_personal_no(),get_product_no(),get_overDue_date())