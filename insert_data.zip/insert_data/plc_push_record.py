# 2020/12/22
# author:xieyudong
import pymysql
import time
from tools import *
db = choose_env('test')
cursor = db.cursor()
def insert_plc_push_record():
    sql = """insert into plc_push_record(
                    batch_type,
                    batch_status,
                    batch_no,
                    created_time,
                    modified_time
        )values(%s,%s,%s,%s,%s)"""
    params = ('DAY', 'PUSH_FINISH', 10000001, get_time('precise_time'), get_time('precise_time')),
    cursor.executemany(sql, params)
    db.commit()
if __name__ == '__main__':
    insert_plc_push_record()
