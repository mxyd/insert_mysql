# 2020/12/21
# author:xieyudong
"""客户表"""
import pymysql
import datetime
from tools import *
db = choose_env('test')
cursor = db.cursor()
def insert_to_personal_temp(per_n2,idCard,usertype):
    """

    :param per_n2: 客户号
    :return:
    """
    batch_no='10000002'
    personal_type = usertype
    personal_no = per_n2
    personal_name = get_name()
    id_type = 'ID_CARD'
    id_card =  idCard
    english_name = 'Tom'
    sex = 'male'
    birthday = get_time('otime')
    nationality = '中国'
    language = '中文'
    nation = '汉'
    education = '大专'
    graduate_school = '上海大学'
    enrollment_time = '2009-09-01'
    graduation_time = '2013-07-05'
    income = '5000'
    id_card_address = '上海'
    mobile_no_address = '上海'
    ip_address = '上海'
    online_status = '在线'
    personal_rank = '一级'
    first_date = get_time('precise_time')
    up_months = 1
    company_name = '招东银行'
    industry = '银行'
    company_type = '国企'
    occupation = '一级'
    marital = '未婚'
    house_type = '租房'
    local_phone_area_code = '029'
    local_phone = get_pnone_number()
    company_phone_area_code = '029'
    company_phone = get_pnone_number()
    register_phone_area_code = '西安'
    register_phone = get_pnone_number()
    deposit_account_flag = '一般客户'
    wechat_no_flag = '是'
    email_flag = '是'
    risk_flag = '高'
    lately_pay_date = get_time('otime')
    lately_pay_amount = round(random.uniform(10001.00,999999.99))
    total_accounts = 5
    merge_accounts = 5
    net_interest_flag = '是'
    delay_max_account_no = '600001'
    delay_max_account_type = '房产账户'
    history_max_overdue_stage = '5'
    credit_code = '91420100333437374F'
    org_code = '333437374'
    texpayer_id = '91420100333437374F'
    establishment_date = get_time('precise_time')
    license_start_time = get_time('otime')
    registered_capital = 2234155300.00
    registration_time = get_time('otime')
    public_bank_card_number = get_bank_card_number()
    public_bank_name = '中国银行'
    business_scope = '医疗护理'
    legal_name = '张三'
    legal_id_card = get_id_card()
    legal_sex = 'male'
    legal_card_number = get_bank_card_number()
    legal_mobile_no = get_pnone_number()
    core_enterprise_no = '11111111'
    core_enterprise_name = '招东银行'
    core_enterprise_adress = '上海市浦东区龙阳路'
    phone = get_pnone_number()
    email = '1366666666@163.com'
    wechat = get_pnone_number()
    dataList = []
    data = (
        (batch_no,
         personal_type,
         personal_no,
         personal_name,
         id_type,
         id_card,
         english_name,
         sex,
         birthday,
         nationality,
         language,
         nation,
         education,
         graduate_school,
        enrollment_time,
         graduation_time,
         income,
         id_card_address,
         mobile_no_address,
         ip_address,
         online_status,
         personal_rank,
         first_date,
         up_months,
         company_name,
         industry,
         company_type,
         occupation,
         marital,
         house_type,
         local_phone_area_code,
         local_phone,
         company_phone_area_code,
         company_phone,
         register_phone_area_code,
         register_phone,
         deposit_account_flag,
         wechat_no_flag,
         email_flag,
         risk_flag,
         lately_pay_date,
         lately_pay_amount,
         total_accounts,
         merge_accounts,
         net_interest_flag,
         delay_max_account_no,
         delay_max_account_type,
         history_max_overdue_stage,
         credit_code,
         org_code,
         texpayer_id,
         establishment_date,
         license_start_time,
         registered_capital,
         registration_time,
         public_bank_card_number,
         public_bank_name,
         business_scope,
         legal_name,
         legal_id_card,
         legal_sex,
         legal_card_number,
         legal_mobile_no,
         core_enterprise_no,
         core_enterprise_name,
         core_enterprise_adress,
         phone,
         email,
         wechat
         )
    )
    dataList.append(data)
    sql = """insert into plc_personal_temp(
         batch_no,
         personal_type,
         personal_no,
         personal_name,
         id_type,
         id_card,
         english_name,
         sex,
         birthday,
         nationality,
         language,
         nation,
         education,
         graduate_school,
        enrollment_time,
         graduation_time,
         income,
         id_card_address,
         mobile_no_address,
         ip_address,
         online_status,
         personal_rank,
         first_date,
         up_months,
         company_name,
         industry,
         company_type,
         occupation,
         marital,
         house_type,
         local_phone_area_code,
         local_phone,
         company_phone_area_code,
         company_phone,
         register_phone_area_code,
         register_phone,
         deposit_account_flag,
         wechat_no_flag,
         email_flag,
         risk_flag,
         lately_pay_date,
         lately_pay_amount,
         total_accounts,
         merge_accounts,
         net_interest_flag,
         delay_max_account_no,
         delay_max_account_type,
         history_max_overdue_stage,
         credit_code,
         org_code,
         texpayer_id,
         establishment_date,
         license_start_time,
         registered_capital,
         registration_time,
         public_bank_card_number,
         public_bank_name,
         business_scope,
         legal_name,
         legal_id_card,
         legal_sex,
         legal_card_number,
         legal_mobile_no,
         core_enterprise_no,
         core_enterprise_name,
         core_enterprise_adress,
         phone,
         email,
         wechat
        ) values(
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
        %s,%s,%s,%s,%s,%s,%s,%s,%s
        )"""
    cursor.executemany(sql, dataList)
    db.commit()





